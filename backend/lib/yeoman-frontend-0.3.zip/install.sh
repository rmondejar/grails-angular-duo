zip -r yeoman-frontend-0.3.zip * -x yeoman-frontend-0.3.zip
mv yeoman-frontend-0.3.zip /home/mabertran/workspace/plantidoc/backend/lib/
rm /home/mabertran/.grails/ivy-cache/org.grails.plugins/yeoman-frontend/zips/yeoman-frontend-0.3.zip
